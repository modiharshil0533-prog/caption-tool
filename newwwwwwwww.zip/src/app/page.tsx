import CaptionStudio from "@/components/CaptionStudio";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <CaptionStudio />;
}
