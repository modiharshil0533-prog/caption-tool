import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "CaptionForge — Automatic Video Captions",
  description:
    "Upload a video, generate automatic captions with offline AI speech recognition, style them with fonts & colors, position them anywhere, and export an MP4.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#0b0d14] text-slate-100 antialiased">{children}</body>
    </html>
  );
}
