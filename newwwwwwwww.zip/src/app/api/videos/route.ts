import { nanoid } from "nanoid";
import path from "path";
import { promises as fs } from "fs";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { ensureStorageDirs, uploadPath } from "@/lib/storage";
import { probeVideo } from "@/lib/ffmpeg";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

const ALLOWED_EXT = new Set(["mp4", "mov", "webm", "mkv", "avi", "m4v"]);
const MAX_BYTES = 500 * 1024 * 1024; // 500MB safety cap

function extFromName(name: string): string {
  const ext = name.split(".").pop()?.toLowerCase() ?? "mp4";
  return ALLOWED_EXT.has(ext) ? ext : "mp4";
}

export async function GET() {
  const rows = await db.select().from(videos).orderBy(desc(videos.createdAt)).limit(25);
  return Response.json({ videos: rows });
}

export async function POST(req: Request) {
  try {
    await ensureStorageDirs();
    const form = await req.formData();
    const file = form.get("file");

    if (!(file instanceof File)) {
      return Response.json({ error: "No video file provided." }, { status: 400 });
    }
    if (!file.type.startsWith("video/")) {
      return Response.json({ error: "Please upload a video file." }, { status: 400 });
    }
    if (file.size > MAX_BYTES) {
      return Response.json({ error: "Video is too large (max 500MB)." }, { status: 400 });
    }

    const id = nanoid(12);
    const ext = extFromName(file.name || "video.mp4");
    const fileName = `${id}.${ext}`;
    const destPath = uploadPath(fileName);

    const arrayBuffer = await file.arrayBuffer();
    await fs.writeFile(destPath, Buffer.from(arrayBuffer));

    let probe;
    try {
      probe = await probeVideo(destPath);
    } catch (err) {
      await fs.unlink(destPath).catch(() => {});
      return Response.json(
        { error: "Could not read the video file. It may be corrupted or in an unsupported format." },
        { status: 400 },
      );
    }

    if (!probe.durationMs) {
      await fs.unlink(destPath).catch(() => {});
      return Response.json({ error: "Could not determine video duration." }, { status: 400 });
    }

    const [row] = await db
      .insert(videos)
      .values({
        id,
        originalName: file.name || fileName,
        mimeType: file.type,
        fileExt: ext,
        storagePath: path.relative(process.cwd(), destPath),
        sizeBytes: file.size,
        durationMs: probe.durationMs,
        width: probe.width,
        height: probe.height,
        status: "uploaded",
      })
      .returning();

    return Response.json({ video: row });
  } catch (err) {
    console.error("upload error", err);
    return Response.json({ error: "Upload failed. Please try again." }, { status: 500 });
  }
}
