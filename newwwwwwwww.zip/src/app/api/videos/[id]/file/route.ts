import path from "path";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { eq } from "drizzle-orm";
import { streamFileResponse } from "@/lib/file-stream";

export const dynamic = "force-dynamic";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [video] = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  if (!video) {
    return Response.json({ error: "Video not found." }, { status: 404 });
  }
  const filePath = path.join(process.cwd(), video.storagePath);
  try {
    return await streamFileResponse(filePath, req, { contentType: video.mimeType || "video/mp4" });
  } catch {
    return Response.json({ error: "Video file missing." }, { status: 404 });
  }
}
