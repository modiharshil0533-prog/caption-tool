import { db } from "@/db";
import { captions } from "@/db/schema";
import { and, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rows = await db.select().from(captions).where(eq(captions.videoId, id));
  return Response.json({ captions: rows.sort((a, b) => a.orderIndex - b.orderIndex) });
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json().catch(() => null);
  if (!body || !Array.isArray(body.captions)) {
    return Response.json({ error: "Invalid payload." }, { status: 400 });
  }

  for (const cue of body.captions as Array<{ id: string; text: string }>) {
    if (!cue.id || typeof cue.text !== "string") continue;
    await db
      .update(captions)
      .set({ text: cue.text, edited: true })
      .where(and(eq(captions.id, cue.id), eq(captions.videoId, id)));
  }

  const rows = await db.select().from(captions).where(eq(captions.videoId, id));
  return Response.json({ captions: rows.sort((a, b) => a.orderIndex - b.orderIndex) });
}
