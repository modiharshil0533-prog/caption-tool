import path from "path";
import { nanoid } from "nanoid";
import { promises as fs } from "fs";
import { db } from "@/db";
import { videos, captions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureStorageDirs, tmpPath } from "@/lib/storage";
import { extractAudioToWav } from "@/lib/ffmpeg";
import { transcribeWavToWords, groupWordsIntoCues } from "@/lib/whisper";

export const dynamic = "force-dynamic";
export const maxDuration = 600;

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [video] = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  if (!video) {
    return Response.json({ error: "Video not found." }, { status: 404 });
  }

  await ensureStorageDirs();
  await db.update(videos).set({ status: "transcribing", errorMessage: null }).where(eq(videos.id, id));

  const jobId = nanoid(8);
  const wavPath = tmpPath(`${id}-${jobId}.wav`);
  const outPrefix = tmpPath(`${id}-${jobId}`);
  const inputPath = path.join(process.cwd(), video.storagePath);

  try {
    await extractAudioToWav(inputPath, wavPath);
    const words = await transcribeWavToWords(wavPath, outPrefix);
    const cues = groupWordsIntoCues(words);

    await db.delete(captions).where(eq(captions.videoId, id));

    if (cues.length > 0) {
      await db.insert(captions).values(
        cues.map((cue) => ({
          id: nanoid(10),
          videoId: id,
          orderIndex: cue.orderIndex,
          startMs: cue.startMs,
          endMs: cue.endMs,
          text: cue.text,
        })),
      );
    }

    await db.update(videos).set({ status: "ready" }).where(eq(videos.id, id));

    const savedCaptions = await db
      .select()
      .from(captions)
      .where(eq(captions.videoId, id));

    return Response.json({
      captions: savedCaptions.sort((a, b) => a.orderIndex - b.orderIndex),
      warning: cues.length === 0 ? "No speech was detected in this video." : undefined,
    });
  } catch (err) {
    console.error("transcribe error", err);
    const message = err instanceof Error ? err.message : "Transcription failed.";
    await db
      .update(videos)
      .set({ status: "error", errorMessage: message.slice(0, 500) })
      .where(eq(videos.id, id));
    return Response.json({ error: "Automatic captioning failed. Please try again." }, { status: 500 });
  } finally {
    await fs.unlink(wavPath).catch(() => {});
  }
}
