import { db } from "@/db";
import { videos } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [video] = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  if (!video) {
    return Response.json({ error: "Video not found." }, { status: 404 });
  }
  return Response.json({ video });
}
