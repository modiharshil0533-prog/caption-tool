import path from "path";
import { db } from "@/db";
import { renders } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { streamFileResponse } from "@/lib/file-stream";

export const dynamic = "force-dynamic";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string; renderId: string }> },
) {
  const { id, renderId } = await params;
  const [render] = await db
    .select()
    .from(renders)
    .where(and(eq(renders.id, renderId), eq(renders.videoId, id)))
    .limit(1);

  if (!render || render.status !== "done" || !render.storagePath) {
    return Response.json({ error: "Render not ready." }, { status: 404 });
  }

  const url = new URL(req.url);
  const download = url.searchParams.get("download") === "1";
  const filePath = path.join(process.cwd(), render.storagePath);

  try {
    return await streamFileResponse(filePath, req, {
      contentType: "video/mp4",
      downloadName: download ? `captioned-${renderId}.mp4` : undefined,
    });
  } catch {
    return Response.json({ error: "Render file missing." }, { status: 404 });
  }
}
