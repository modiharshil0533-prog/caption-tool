import path from "path";
import { nanoid } from "nanoid";
import { db } from "@/db";
import { videos, captions, renders } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { ensureStorageDirs, renderPath, tmpPath } from "@/lib/storage";
import { renderCaptionedVideo } from "@/lib/render";
import { getFont } from "@/lib/fonts";
import { getPalette } from "@/lib/palettes";
import { getFrame } from "@/lib/frames";

export const dynamic = "force-dynamic";
export const maxDuration = 600;

type RenderRequestBody = {
  fontId?: string;
  paletteId?: string;
  fontSizePct?: number;
  positionXPct?: number;
  positionYPct?: number;
  uppercase?: boolean;
  frameId?: string;
  maxWidthPct?: number;
};

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rows = await db.select().from(renders).where(eq(renders.videoId, id)).orderBy(desc(renders.createdAt));
  return Response.json({ renders: rows });
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [video] = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  if (!video) {
    return Response.json({ error: "Video not found." }, { status: 404 });
  }

  const body = (await req.json().catch(() => ({}))) as RenderRequestBody;

  const font = getFont(body.fontId ?? "roboto");
  const palette = getPalette(body.paletteId ?? "classic-white");
  const frame = getFrame(body.frameId ?? "original");
  const fontSizePct = clamp(body.fontSizePct ?? 5.5, 1.5, 15);
  const positionXPct = clamp(body.positionXPct ?? 50, 0, 100);
  const positionYPct = clamp(body.positionYPct ?? 82, 0, 100);
  const maxWidthPct = clamp(body.maxWidthPct ?? 82, 30, 100);
  const uppercase = Boolean(body.uppercase);

  const cueRows = await db
    .select()
    .from(captions)
    .where(eq(captions.videoId, id));
  const cues = cueRows
    .sort((a, b) => a.orderIndex - b.orderIndex)
    .map((c) => ({ orderIndex: c.orderIndex, startMs: c.startMs, endMs: c.endMs, text: c.text }));

  await ensureStorageDirs();

  const useOriginal = frame.id === "original";
  const outputHeightForSizing = useOriginal ? video.height || 1920 : frame.height;
  const fontSizePx = Math.round((fontSizePct / 100) * outputHeightForSizing);

  const renderId = nanoid(12);
  const settings = {
    fontId: font.id,
    paletteId: palette.id,
    fontSizePct,
    positionXPct,
    positionYPct,
    uppercase,
    frameId: frame.id,
    maxWidthPct,
  };

  const [renderRow] = await db
    .insert(renders)
    .values({
      id: renderId,
      videoId: id,
      status: "processing",
      settings,
    })
    .returning();

  const inputPath = path.join(process.cwd(), video.storagePath);
  const outputFileName = `${renderId}.mp4`;
  const outputPath = renderPath(outputFileName);
  const assTmpPath = tmpPath(`${renderId}.ass`);

  try {
    const result = await renderCaptionedVideo(
      {
        inputPath,
        outputPath,
        sourceWidth: video.width,
        sourceHeight: video.height,
        frameWidth: useOriginal ? 0 : frame.width,
        frameHeight: useOriginal ? 0 : frame.height,
      },
      cues,
      {
        font,
        palette,
        fontSizePx,
        positionXPct,
        positionYPct,
        uppercase,
        outputWidth: useOriginal ? video.width : frame.width,
        outputHeight: useOriginal ? video.height : frame.height,
        maxWidthPct,
      },
      assTmpPath,
    );

    const [updated] = await db
      .update(renders)
      .set({
        status: "done",
        storagePath: path.relative(process.cwd(), outputPath),
        outputWidth: result.outputWidth,
        outputHeight: result.outputHeight,
        completedAt: new Date(),
      })
      .where(eq(renders.id, renderId))
      .returning();

    return Response.json({ render: updated });
  } catch (err) {
    console.error("render error", err);
    const message = err instanceof Error ? err.message : "Render failed.";
    const [updated] = await db
      .update(renders)
      .set({ status: "error", errorMessage: message.slice(0, 1000) })
      .where(eq(renders.id, renderId))
      .returning();
    return Response.json({ error: "Rendering failed. Please try again.", render: updated }, { status: 500 });
  } finally {
    void renderRow;
  }
}
