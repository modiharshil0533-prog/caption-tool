"use client";

import { useCallback, useRef, useState } from "react";
import UploadDropzone from "./UploadDropzone";
import PreviewStage from "./PreviewStage";
import ControlsPanel from "./ControlsPanel";
import CaptionsList from "./CaptionsList";
import type { CaptionRecord, RenderRecord, StyleSettings, VideoRecord } from "./types";

const DEFAULT_STYLE: StyleSettings = {
  fontId: "montserrat",
  paletteId: "classic-white",
  fontSizePct: 5.5,
  positionXPct: 50,
  positionYPct: 82,
  uppercase: true,
  frameId: "original",
  maxWidthPct: 82,
};

type Phase = "upload" | "studio";

export default function CaptionStudio() {
  const [phase, setPhase] = useState<Phase>("upload");
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const [video, setVideo] = useState<VideoRecord | null>(null);
  const [captions, setCaptions] = useState<CaptionRecord[]>([]);
  const [transcribing, setTranscribing] = useState(false);
  const [transcribeError, setTranscribeError] = useState<string | null>(null);
  const [transcribeNote, setTranscribeNote] = useState<string | null>(null);
  const [savingCaptions, setSavingCaptions] = useState(false);

  const [style, setStyle] = useState<StyleSettings>(DEFAULT_STYLE);

  const [rendering, setRendering] = useState(false);
  const [renderError, setRenderError] = useState<string | null>(null);
  const [render, setRender] = useState<RenderRecord | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);

  const handleUpload = useCallback(async (file: File) => {
    setUploading(true);
    setUploadError(null);
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch("/api/videos", { method: "POST", body: form });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Upload failed.");
      }
      setVideo(data.video);
      setPhase("studio");
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : "Upload failed.");
    } finally {
      setUploading(false);
    }
  }, []);

  const handleTranscribe = useCallback(async () => {
    if (!video) return;
    setTranscribing(true);
    setTranscribeError(null);
    setTranscribeNote(null);
    try {
      const res = await fetch(`/api/videos/${video.id}/transcribe`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Transcription failed.");
      }
      setCaptions(data.captions || []);
      if (data.warning) setTranscribeNote(data.warning);
      setVideo((v) => (v ? { ...v, status: "ready" } : v));
    } catch (err) {
      setTranscribeError(err instanceof Error ? err.message : "Transcription failed.");
    } finally {
      setTranscribing(false);
    }
  }, [video]);

  const handleSaveCaptions = useCallback(
    async (updates: { id: string; text: string }[]) => {
      if (!video || updates.length === 0) return;
      setSavingCaptions(true);
      try {
        const res = await fetch(`/api/videos/${video.id}/captions`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ captions: updates }),
        });
        const data = await res.json();
        if (res.ok) setCaptions(data.captions);
      } finally {
        setSavingCaptions(false);
      }
    },
    [video],
  );

  const handleStyleChange = useCallback((patch: Partial<StyleSettings>) => {
    setStyle((s) => ({ ...s, ...patch }));
  }, []);

  const handlePositionChange = useCallback((xPct: number, yPct: number) => {
    setStyle((s) => ({ ...s, positionXPct: xPct, positionYPct: yPct }));
  }, []);

  const handleRender = useCallback(async () => {
    if (!video) return;
    setRendering(true);
    setRenderError(null);
    setRender(null);
    try {
      const res = await fetch(`/api/videos/${video.id}/render`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(style),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Render failed.");
      }
      setRender(data.render);
    } catch (err) {
      setRenderError(err instanceof Error ? err.message : "Render failed.");
    } finally {
      setRendering(false);
    }
  }, [video, style]);

  const handleStartOver = useCallback(() => {
    setPhase("upload");
    setVideo(null);
    setCaptions([]);
    setRender(null);
    setRenderError(null);
    setTranscribeError(null);
    setTranscribeNote(null);
    setStyle(DEFAULT_STYLE);
  }, []);

  if (phase === "upload" || !video) {
    return (
      <main className="min-h-screen bg-[#0b0d14]">
        <UploadDropzone onUpload={handleUpload} uploading={uploading} error={uploadError} />
      </main>
    );
  }

  const videoUrl = `/api/videos/${video.id}/file`;

  return (
    <main className="min-h-screen bg-[#0b0d14] pb-24">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-5 py-6">
        <div className="flex items-center gap-2">
          <span className="text-xl font-bold text-white">
            Caption<span className="text-indigo-400">Forge</span>
          </span>
          <span className="hidden rounded-full bg-slate-800 px-2.5 py-0.5 text-[11px] font-medium text-slate-400 sm:inline">
            {video.originalName}
          </span>
        </div>
        <button
          onClick={handleStartOver}
          className="rounded-lg border border-slate-700 px-3 py-1.5 text-xs font-medium text-slate-300 transition hover:border-slate-500"
        >
          ↺ Start over
        </button>
      </header>

      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-8 px-5 lg:grid-cols-[1fr_380px]">
        {/* Left: preview + captions */}
        <div className="flex flex-col gap-6">
          <PreviewStage
            videoUrl={videoUrl}
            sourceWidth={video.width}
            sourceHeight={video.height}
            captions={captions}
            style={style}
            onPositionChange={handlePositionChange}
            videoRef={videoRef}
          />

          <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            <div className="mb-3 flex items-center justify-between gap-3">
              <div>
                <h2 className="text-sm font-semibold text-white">Automatic captions</h2>
                <p className="text-xs text-slate-500">
                  Speech-to-text runs locally — no typing, no third-party API needed.
                </p>
              </div>
              <button
                onClick={handleTranscribe}
                disabled={transcribing}
                className="shrink-0 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-semibold text-white transition hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-50"
              >
                {transcribing
                  ? "Transcribing…"
                  : captions.length > 0
                    ? "Regenerate captions"
                    : "Generate automatic captions"}
              </button>
            </div>

            {transcribing && (
              <p className="mb-3 text-xs text-amber-300">
                Listening to the audio and transcribing speech… this can take a little while for
                longer videos.
              </p>
            )}
            {transcribeError && (
              <p className="mb-3 rounded-lg bg-red-500/10 px-3 py-2 text-xs text-red-300">
                {transcribeError}
              </p>
            )}
            {transcribeNote && (
              <p className="mb-3 rounded-lg bg-amber-500/10 px-3 py-2 text-xs text-amber-300">
                {transcribeNote}
              </p>
            )}

            <CaptionsList captions={captions} onSave={handleSaveCaptions} saving={savingCaptions} />
          </div>
        </div>

        {/* Right: controls */}
        <aside className="flex flex-col gap-6">
          <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            <ControlsPanel style={style} onChange={handleStyleChange} />
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            <h3 className="mb-3 text-sm font-semibold text-white">Export</h3>
            <button
              onClick={handleRender}
              disabled={rendering || captions.length === 0}
              className="w-full rounded-xl bg-emerald-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-emerald-500 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {rendering ? "Rendering your video…" : "🎞️ Render captioned MP4"}
            </button>
            {captions.length === 0 && (
              <p className="mt-2 text-[11px] text-slate-500">
                Generate captions first, then render.
              </p>
            )}
            {rendering && (
              <p className="mt-3 text-xs text-amber-300">
                Burning captions into the video and encoding MP4. Larger videos take longer.
              </p>
            )}
            {renderError && (
              <p className="mt-3 rounded-lg bg-red-500/10 px-3 py-2 text-xs text-red-300">
                {renderError}
              </p>
            )}

            {render && render.status === "done" && (
              <div className="mt-4 flex flex-col gap-3 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3">
                <p className="text-xs font-medium text-emerald-300">
                  ✅ Done — {render.outputWidth}×{render.outputHeight}
                </p>
                <video
                  src={`/api/videos/${video.id}/render/${render.id}/file`}
                  controls
                  className="w-full rounded-lg bg-black"
                />
                <a
                  href={`/api/videos/${video.id}/render/${render.id}/file?download=1`}
                  download
                  className="w-full rounded-lg bg-white px-4 py-2.5 text-center text-sm font-semibold text-slate-900 transition hover:bg-slate-200"
                >
                  ⬇ Download final MP4
                </a>
              </div>
            )}
          </div>
        </aside>
      </div>
    </main>
  );
}
