"use client";

import { FONT_OPTIONS } from "@/lib/fonts";
import { PALETTE_OPTIONS } from "@/lib/palettes";
import { FRAME_OPTIONS } from "@/lib/frames";
import type { StyleSettings } from "./types";

export default function ControlsPanel({
  style,
  onChange,
}: {
  style: StyleSettings;
  onChange: (patch: Partial<StyleSettings>) => void;
}) {
  return (
    <div className="flex flex-col gap-7">
      <Section title="Font" subtitle="10 caption fonts">
        <div className="grid grid-cols-2 gap-2">
          {FONT_OPTIONS.map((f) => (
            <button
              key={f.id}
              onClick={() => onChange({ fontId: f.id })}
              className={`rounded-xl border px-3 py-2.5 text-left transition ${
                style.fontId === f.id
                  ? "border-indigo-400 bg-indigo-500/15 text-white"
                  : "border-slate-700 bg-slate-900/50 text-slate-300 hover:border-slate-500"
              }`}
              style={{ fontFamily: f.cssFallback, fontWeight: f.bold ? 700 : 400 }}
            >
              <span className="block truncate text-sm">{f.label}</span>
            </button>
          ))}
        </div>
      </Section>

      <Section title="Color palette" subtitle="20 ready-made styles">
        <div className="grid grid-cols-5 gap-2.5">
          {PALETTE_OPTIONS.map((p) => (
            <button
              key={p.id}
              title={p.label}
              onClick={() => onChange({ paletteId: p.id })}
              className={`group relative flex aspect-square items-center justify-center rounded-xl border transition ${
                style.paletteId === p.id
                  ? "border-indigo-400 ring-2 ring-indigo-400/60"
                  : "border-slate-700 hover:border-slate-500"
              }`}
              style={{ backgroundColor: p.box ?? "#111827" }}
            >
              <span
                className="text-base font-extrabold"
                style={{
                  color: p.text,
                  WebkitTextStroke: p.box ? "none" : `1.5px ${p.outline}`,
                }}
              >
                Aa
              </span>
            </button>
          ))}
        </div>
      </Section>

      <Section title="Frame size" subtitle="Output aspect ratio">
        <div className="grid grid-cols-2 gap-2">
          {FRAME_OPTIONS.map((f) => (
            <button
              key={f.id}
              onClick={() => onChange({ frameId: f.id })}
              className={`flex flex-col items-start gap-0.5 rounded-xl border px-3 py-2.5 text-left transition ${
                style.frameId === f.id
                  ? "border-indigo-400 bg-indigo-500/15 text-white"
                  : "border-slate-700 bg-slate-900/50 text-slate-300 hover:border-slate-500"
              }`}
            >
              <span className="text-sm font-semibold">{f.label}</span>
              <span className="text-[11px] text-slate-500">
                {f.id === "original" ? "Source size" : `${f.width}×${f.height}`}
              </span>
            </button>
          ))}
        </div>
      </Section>

      <Section title="Caption size" subtitle={`${style.fontSizePct.toFixed(1)}% of frame height`}>
        <input
          type="range"
          min={1.5}
          max={15}
          step={0.1}
          value={style.fontSizePct}
          onChange={(e) => onChange({ fontSizePct: parseFloat(e.target.value) })}
          className="w-full"
        />
      </Section>

      <Section title="Max caption width" subtitle={`${style.maxWidthPct.toFixed(0)}% of frame width`}>
        <input
          type="range"
          min={30}
          max={100}
          step={1}
          value={style.maxWidthPct}
          onChange={(e) => onChange({ maxWidthPct: parseFloat(e.target.value) })}
          className="w-full"
        />
      </Section>

      <Section title="Position" subtitle="Drag the caption in the preview, or snap">
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Top", x: 50, y: 14 },
            { label: "Center", x: 50, y: 50 },
            { label: "Bottom", x: 50, y: 86 },
          ].map((p) => (
            <button
              key={p.label}
              onClick={() => onChange({ positionXPct: p.x, positionYPct: p.y })}
              className="rounded-xl border border-slate-700 bg-slate-900/50 px-3 py-2 text-xs font-medium text-slate-300 transition hover:border-slate-500"
            >
              {p.label}
            </button>
          ))}
        </div>
      </Section>

      <Section title="Text case" subtitle="Toggle uppercase styling">
        <button
          onClick={() => onChange({ uppercase: !style.uppercase })}
          className={`w-full rounded-xl border px-3 py-2.5 text-sm font-semibold transition ${
            style.uppercase
              ? "border-indigo-400 bg-indigo-500/15 text-white"
              : "border-slate-700 bg-slate-900/50 text-slate-300 hover:border-slate-500"
          }`}
        >
          {style.uppercase ? "UPPERCASE: ON" : "Uppercase: off"}
        </button>
      </Section>
    </div>
  );
}

function Section({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <div className="mb-2.5 flex items-baseline justify-between">
        <h3 className="text-sm font-semibold text-white">{title}</h3>
        <span className="text-[11px] text-slate-500">{subtitle}</span>
      </div>
      {children}
    </div>
  );
}
