"use client";

import { useState } from "react";
import type { CaptionRecord } from "./types";

function formatTime(ms: number) {
  const totalSec = Math.floor(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export default function CaptionsList({
  captions,
  onSave,
  saving,
}: {
  captions: CaptionRecord[];
  onSave: (updated: { id: string; text: string }[]) => void;
  saving: boolean;
}) {
  const [draft, setDraft] = useState<Record<string, string>>({});
  const dirty = Object.keys(draft).length > 0;

  function update(id: string, text: string) {
    setDraft((d) => ({ ...d, [id]: text }));
  }

  function save() {
    const updates = Object.entries(draft).map(([id, text]) => ({ id, text }));
    onSave(updates);
    setDraft({});
  }

  if (captions.length === 0) {
    return (
      <p className="rounded-xl border border-dashed border-slate-700 px-4 py-6 text-center text-sm text-slate-500">
        No captions yet. Click &quot;Generate automatic captions&quot; above — speech is transcribed
        for you, nothing to type.
      </p>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="max-h-72 overflow-y-auto rounded-xl border border-slate-800">
        {captions.map((c, i) => (
          <div
            key={c.id}
            className={`flex items-start gap-3 px-3 py-2.5 text-sm ${
              i !== captions.length - 1 ? "border-b border-slate-800" : ""
            }`}
          >
            <span className="mt-1 shrink-0 font-mono text-[11px] text-slate-500">
              {formatTime(c.startMs)}
            </span>
            <input
              value={draft[c.id] ?? c.text}
              onChange={(e) => update(c.id, e.target.value)}
              className="w-full rounded-md border border-transparent bg-transparent px-2 py-1 text-slate-200 outline-none transition focus:border-indigo-500 focus:bg-slate-900"
            />
          </div>
        ))}
      </div>
      <div className="flex items-center justify-between">
        <span className="text-xs text-slate-500">
          Auto-generated — tweak only if speech recognition missed a word.
        </span>
        <button
          disabled={!dirty || saving}
          onClick={save}
          className="rounded-lg bg-indigo-600 px-3.5 py-1.5 text-xs font-semibold text-white transition hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {saving ? "Saving…" : "Save edits"}
        </button>
      </div>
    </div>
  );
}
