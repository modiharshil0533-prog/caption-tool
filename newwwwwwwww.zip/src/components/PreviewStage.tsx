"use client";

import { useEffect, useRef, useState, type RefObject } from "react";
import { getFont } from "@/lib/fonts";
import { getPalette } from "@/lib/palettes";
import { getFrame } from "@/lib/frames";
import type { CaptionRecord, StyleSettings } from "./types";

export default function PreviewStage({
  videoUrl,
  sourceWidth,
  sourceHeight,
  captions,
  style,
  onPositionChange,
  videoRef,
}: {
  videoUrl: string;
  sourceWidth: number;
  sourceHeight: number;
  captions: CaptionRecord[];
  style: StyleSettings;
  onPositionChange: (xPct: number, yPct: number) => void;
  videoRef: RefObject<HTMLVideoElement | null>;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [currentMs, setCurrentMs] = useState(0);
  const [containerSize, setContainerSize] = useState({ w: 0, h: 0 });
  const [dragging, setDragging] = useState(false);

  const frame = getFrame(style.frameId);
  const isOriginal = frame.id === "original";
  const aspectW = isOriginal ? sourceWidth || 9 : frame.width;
  const aspectH = isOriginal ? sourceHeight || 16 : frame.height;

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) {
        setContainerSize({ w: entry.contentRect.width, h: entry.contentRect.height });
      }
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    const onTime = () => setCurrentMs(video.currentTime * 1000);
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("seeking", onTime);
    return () => {
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("seeking", onTime);
    };
  }, [videoRef]);

  const activeCue = captions.find((c) => currentMs >= c.startMs && currentMs <= c.endMs);
  const displayText = activeCue?.text ?? "Your captions will appear here";
  const font = getFont(style.fontId);
  const palette = getPalette(style.paletteId);

  const fontSizePx = (style.fontSizePct / 100) * containerSize.h;
  const maxWidthPx = (style.maxWidthPct / 100) * containerSize.w;

  function clientToPct(clientX: number, clientY: number) {
    const el = containerRef.current;
    if (!el) return null;
    const rect = el.getBoundingClientRect();
    const xPct = ((clientX - rect.left) / rect.width) * 100;
    const yPct = ((clientY - rect.top) / rect.height) * 100;
    return { x: Math.min(100, Math.max(0, xPct)), y: Math.min(100, Math.max(0, yPct)) };
  }

  function handlePointerDown(e: React.PointerEvent) {
    e.preventDefault();
    setDragging(true);
    (e.target as Element).setPointerCapture(e.pointerId);
  }
  function handlePointerMove(e: React.PointerEvent) {
    if (!dragging) return;
    const pos = clientToPct(e.clientX, e.clientY);
    if (pos) onPositionChange(pos.x, pos.y);
  }
  function handlePointerUp(e: React.PointerEvent) {
    setDragging(false);
    try {
      (e.target as Element).releasePointerCapture(e.pointerId);
    } catch {}
  }

  return (
    <div className="flex flex-col items-center gap-3">
      <div
        ref={containerRef}
        className="relative w-full max-w-md overflow-hidden rounded-2xl bg-black shadow-2xl ring-1 ring-white/10"
        style={{ aspectRatio: `${aspectW} / ${aspectH}` }}
      >
        <video
          ref={videoRef}
          src={videoUrl}
          controls
          playsInline
          className="absolute inset-0 h-full w-full"
          style={{ objectFit: isOriginal ? "contain" : "cover" }}
        />

        {/* draggable caption chip */}
        <div
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="absolute flex cursor-grab touch-none select-none items-center justify-center active:cursor-grabbing"
          style={{
            left: `${style.positionXPct}%`,
            top: `${style.positionYPct}%`,
            transform: "translate(-50%, -50%)",
            maxWidth: `${maxWidthPx}px`,
          }}
          title="Drag to reposition captions"
        >
          <span
            className="caption-text-stroke whitespace-pre-wrap break-words text-center leading-tight"
            style={{
              fontFamily: font.cssFallback,
              fontWeight: font.bold ? 700 : 400,
              color: palette.text,
              fontSize: `${Math.max(fontSizePx, 10)}px`,
              textTransform: style.uppercase ? "uppercase" : "none",
              backgroundColor: palette.box
                ? hexToRgba(palette.box, palette.boxOpacity)
                : "transparent",
              padding: palette.box ? "0.15em 0.4em" : 0,
              borderRadius: palette.box ? "0.2em" : 0,
              ["--stroke-w" as string]: palette.box ? "0px" : `${Math.max(fontSizePx * 0.045, 1)}px`,
              ["--stroke-color" as string]: palette.outline,
              boxShadow: dragging ? "0 0 0 2px rgba(99,102,241,0.8)" : "none",
            }}
          >
            {displayText}
          </span>
        </div>
      </div>
      <p className="text-xs text-slate-500">Drag the caption text on the preview to place it anywhere.</p>
    </div>
  );
}

function hexToRgba(hex: string, alpha: number) {
  const clean = hex.replace("#", "");
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
