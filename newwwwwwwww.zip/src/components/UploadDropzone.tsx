"use client";

import { useCallback, useRef, useState } from "react";

export default function UploadDropzone({
  onUpload,
  uploading,
  error,
}: {
  onUpload: (file: File) => void;
  uploading: boolean;
  error: string | null;
}) {
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFiles = useCallback(
    (files: FileList | null) => {
      if (!files || files.length === 0) return;
      onUpload(files[0]);
    },
    [onUpload],
  );

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col items-center gap-6 px-4 py-20 text-center">
      <div className="flex items-center gap-2 rounded-full bg-indigo-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-indigo-300 ring-1 ring-indigo-500/30">
        🎬 Automatic AI Captions · Runs fully offline
      </div>
      <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">
        Caption<span className="text-indigo-400">Forge</span>
      </h1>
      <p className="max-w-lg text-balance text-base text-slate-400">
        Upload a video and we&apos;ll automatically transcribe the speech, no typing required.
        Then pick a font, a color palette, drag the caption wherever you want, choose your
        export frame size, and download a finished MP4.
      </p>

      <label
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          handleFiles(e.dataTransfer.files);
        }}
        className={`flex w-full cursor-pointer flex-col items-center justify-center gap-3 rounded-3xl border-2 border-dashed px-8 py-16 transition ${
          dragging
            ? "border-indigo-400 bg-indigo-500/10"
            : "border-slate-700 bg-slate-900/40 hover:border-slate-500 hover:bg-slate-900/60"
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
          disabled={uploading}
        />
        <div className="text-5xl">{uploading ? "⏳" : "📤"}</div>
        <div className="text-lg font-semibold text-white">
          {uploading ? "Uploading & reading video…" : "Drop your video here, or click to browse"}
        </div>
        <div className="text-sm text-slate-500">MP4, MOV, WebM, MKV — up to 500MB</div>
      </label>

      {error && (
        <div className="w-full rounded-xl bg-red-500/10 px-4 py-3 text-sm text-red-300 ring-1 ring-red-500/30">
          {error}
        </div>
      )}
    </div>
  );
}
