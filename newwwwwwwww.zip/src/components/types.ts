export type VideoRecord = {
  id: string;
  originalName: string;
  mimeType: string;
  fileExt: string;
  storagePath: string;
  sizeBytes: number;
  durationMs: number;
  width: number;
  height: number;
  status: "uploaded" | "transcribing" | "ready" | "error";
  errorMessage: string | null;
  createdAt: string;
};

export type CaptionRecord = {
  id: string;
  videoId: string;
  orderIndex: number;
  startMs: number;
  endMs: number;
  text: string;
  edited: boolean;
};

export type RenderRecord = {
  id: string;
  videoId: string;
  status: "processing" | "done" | "error";
  storagePath: string | null;
  errorMessage: string | null;
  settings: Record<string, unknown>;
  outputWidth: number;
  outputHeight: number;
  createdAt: string;
  completedAt: string | null;
};

export type StyleSettings = {
  fontId: string;
  paletteId: string;
  fontSizePct: number;
  positionXPct: number;
  positionYPct: number;
  uppercase: boolean;
  frameId: string;
  maxWidthPct: number;
};
