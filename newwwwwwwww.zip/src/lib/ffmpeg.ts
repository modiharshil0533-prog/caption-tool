import { spawn } from "child_process";
import ffmpegPath from "ffmpeg-static";
import ffprobeStatic from "ffprobe-static";

export const FFMPEG_BIN = (ffmpegPath as unknown as string) || "ffmpeg";
export const FFPROBE_BIN = ffprobeStatic.path || "ffprobe";

export function runCommand(bin: string, args: string[]): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolve, reject) => {
    const child = spawn(bin, args, { stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => (stdout += d.toString()));
    child.stderr.on("data", (d) => (stderr += d.toString()));
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) {
        resolve({ stdout, stderr });
      } else {
        reject(new Error(`${bin} exited with code ${code}\n${stderr.slice(-4000)}`));
      }
    });
  });
}

export type ProbeResult = {
  durationMs: number;
  width: number;
  height: number;
  hasAudio: boolean;
};

export async function probeVideo(filePath: string): Promise<ProbeResult> {
  const { stdout } = await runCommand(FFPROBE_BIN, [
    "-v",
    "error",
    "-print_format",
    "json",
    "-show_format",
    "-show_streams",
    filePath,
  ]);
  const data = JSON.parse(stdout);
  const videoStream = (data.streams || []).find((s: { codec_type: string }) => s.codec_type === "video");
  const audioStream = (data.streams || []).find((s: { codec_type: string }) => s.codec_type === "audio");
  const durationSec = parseFloat(data.format?.duration ?? videoStream?.duration ?? "0");
  let width = videoStream?.width ?? 0;
  let height = videoStream?.height ?? 0;

  // Respect rotation metadata that swaps displayed width/height.
  const rotate =
    videoStream?.tags?.rotate ??
    videoStream?.side_data_list?.find((s: { rotation?: number }) => typeof s.rotation === "number")?.rotation;
  const rotation = rotate ? Math.abs(parseInt(rotate, 10)) % 180 : 0;
  if (rotation === 90 && width && height) {
    [width, height] = [height, width];
  }

  return {
    durationMs: Math.round((isFinite(durationSec) ? durationSec : 0) * 1000),
    width,
    height,
    hasAudio: Boolean(audioStream),
  };
}

export async function extractAudioToWav(inputPath: string, outputWavPath: string) {
  await runCommand(FFMPEG_BIN, [
    "-y",
    "-i",
    inputPath,
    "-vn",
    "-ac",
    "1",
    "-ar",
    "16000",
    "-c:a",
    "pcm_s16le",
    outputWavPath,
  ]);
}
