export type FontOption = {
  id: string;
  label: string;
  /** File name inside public/fonts and vendor font dir used for ffmpeg/libass */
  file: string;
  /** Exact font family name as embedded in the font's name table (must match for libass) */
  family: string;
  /** Google-font-ish fallback stack for the browser preview */
  cssFallback: string;
  bold: boolean;
};

export const FONT_OPTIONS: FontOption[] = [
  {
    id: "roboto",
    label: "Roboto",
    file: "Roboto-Bold.ttf",
    family: "Roboto",
    cssFallback: "'Roboto', Arial, sans-serif",
    bold: true,
  },
  {
    id: "open-sans",
    label: "Open Sans",
    file: "OpenSans-Bold.ttf",
    family: "Open Sans",
    cssFallback: "'Open Sans', Arial, sans-serif",
    bold: true,
  },
  {
    id: "montserrat",
    label: "Montserrat",
    file: "Montserrat-Bold.ttf",
    family: "Montserrat",
    cssFallback: "'Montserrat', Arial, sans-serif",
    bold: true,
  },
  {
    id: "poppins",
    label: "Poppins",
    file: "Poppins-Bold.ttf",
    family: "Poppins",
    cssFallback: "'Poppins', Arial, sans-serif",
    bold: true,
  },
  {
    id: "oswald",
    label: "Oswald",
    file: "Oswald-Bold.ttf",
    family: "Oswald",
    cssFallback: "'Oswald', Impact, sans-serif",
    bold: true,
  },
  {
    id: "bebas-neue",
    label: "Bebas Neue",
    file: "BebasNeue-Regular.ttf",
    family: "Bebas Neue",
    cssFallback: "'Bebas Neue', Impact, sans-serif",
    bold: false,
  },
  {
    id: "anton",
    label: "Anton",
    file: "Anton-Regular.ttf",
    family: "Anton",
    cssFallback: "'Anton', Impact, sans-serif",
    bold: false,
  },
  {
    id: "lobster",
    label: "Lobster",
    file: "Lobster-Regular.ttf",
    family: "Lobster",
    cssFallback: "'Lobster', cursive",
    bold: false,
  },
  {
    id: "pacifico",
    label: "Pacifico",
    file: "Pacifico-Regular.ttf",
    family: "Pacifico",
    cssFallback: "'Pacifico', cursive",
    bold: false,
  },
  {
    id: "inter",
    label: "Inter",
    file: "Inter-Bold.ttf",
    family: "Inter",
    cssFallback: "'Inter', Arial, sans-serif",
    bold: true,
  },
];

export function getFont(id: string): FontOption {
  return FONT_OPTIONS.find((f) => f.id === id) ?? FONT_OPTIONS[0];
}
