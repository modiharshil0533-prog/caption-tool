export type FrameOption = {
  id: string;
  label: string;
  width: number;
  height: number;
  description: string;
};

// "original" is handled dynamically using the source video's own resolution.
export const FRAME_OPTIONS: FrameOption[] = [
  { id: "original", label: "Original", width: 0, height: 0, description: "Keep source size" },
  { id: "9x16", label: "9:16 Reels/TikTok", width: 1080, height: 1920, description: "Vertical" },
  { id: "16x9", label: "16:9 YouTube", width: 1920, height: 1080, description: "Landscape" },
  { id: "1x1", label: "1:1 Square", width: 1080, height: 1080, description: "Square" },
  { id: "4x5", label: "4:5 Instagram", width: 1080, height: 1350, description: "Portrait" },
  { id: "4x3", label: "4:3 Classic", width: 1440, height: 1080, description: "Classic" },
];

export function getFrame(id: string): FrameOption {
  return FRAME_OPTIONS.find((f) => f.id === id) ?? FRAME_OPTIONS[0];
}

export function evenize(n: number) {
  const r = Math.round(n);
  return r % 2 === 0 ? r : r + 1;
}
