import path from "path";
import { promises as fs } from "fs";
import { runCommand } from "./ffmpeg";

const WHISPER_BIN = path.join(process.cwd(), "vendor", "whisper", "bin", "whisper-cli");
const WHISPER_MODEL = path.join(process.cwd(), "vendor", "whisper", "models", "ggml-base.en.bin");

export type WhisperWord = {
  text: string;
  startMs: number;
  endMs: number;
};

type WhisperJsonSegment = {
  offsets: { from: number; to: number };
  text: string;
};

type WhisperJson = {
  transcription: WhisperJsonSegment[];
};

/**
 * Runs the local whisper.cpp binary against a 16kHz mono wav file and
 * returns word-level timestamps. Fully offline, no external API needed.
 */
export async function transcribeWavToWords(wavPath: string, outPrefix: string): Promise<WhisperWord[]> {
  await runCommand(WHISPER_BIN, [
    "-m",
    WHISPER_MODEL,
    "-f",
    wavPath,
    "-ml",
    "1",
    "-sow",
    "-oj",
    "-of",
    outPrefix,
    "-np",
    "-nt",
    "-l",
    "en",
  ]);

  const jsonPath = `${outPrefix}.json`;
  const raw = await fs.readFile(jsonPath, "utf-8");
  const parsed = JSON.parse(raw) as WhisperJson;

  const words: WhisperWord[] = [];
  for (const seg of parsed.transcription ?? []) {
    const text = seg.text.trim();
    if (!text) continue;
    words.push({
      text,
      startMs: seg.offsets.from,
      endMs: seg.offsets.to,
    });
  }

  await fs.unlink(jsonPath).catch(() => {});
  return words;
}

export type CaptionCue = {
  orderIndex: number;
  startMs: number;
  endMs: number;
  text: string;
};

/**
 * Groups raw whisper words into readable caption cues, similar to
 * auto-caption tools: breaks on pauses, punctuation, word count, and max duration.
 */
export function groupWordsIntoCues(words: WhisperWord[]): CaptionCue[] {
  const cues: CaptionCue[] = [];
  const MAX_WORDS = 6;
  const MAX_DURATION_MS = 2600;
  const MAX_GAP_MS = 500;

  let current: WhisperWord[] = [];

  const flush = () => {
    if (current.length === 0) return;
    const text = current.map((w) => w.text).join(" ").replace(/\s+/g, " ").trim();
    if (text) {
      cues.push({
        orderIndex: cues.length,
        startMs: current[0].startMs,
        endMs: current[current.length - 1].endMs,
        text,
      });
    }
    current = [];
  };

  for (const word of words) {
    if (current.length > 0) {
      const prev = current[current.length - 1];
      const gap = word.startMs - prev.endMs;
      const prospectiveDuration = word.endMs - current[0].startMs;
      const endsSentence = /[.!?]$/.test(prev.text);

      if (
        gap > MAX_GAP_MS ||
        current.length >= MAX_WORDS ||
        prospectiveDuration > MAX_DURATION_MS ||
        (endsSentence && current.length >= 3)
      ) {
        flush();
      }
    }
    current.push(word);
  }
  flush();

  return cues;
}
