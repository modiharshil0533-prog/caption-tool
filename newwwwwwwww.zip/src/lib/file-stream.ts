import { createReadStream } from "fs";
import { stat } from "fs/promises";
import type { Readable } from "stream";

function nodeStreamToWeb(stream: Readable): ReadableStream<Uint8Array> {
  return new ReadableStream({
    start(controller) {
      stream.on("data", (chunk) => controller.enqueue(chunk));
      stream.on("end", () => controller.close());
      stream.on("error", (err) => controller.error(err));
    },
    cancel() {
      stream.destroy();
    },
  });
}

export async function streamFileResponse(
  filePath: string,
  req: Request,
  opts: { contentType: string; downloadName?: string },
): Promise<Response> {
  const stats = await stat(filePath);
  const fileSize = stats.size;
  const range = req.headers.get("range");

  const headers: Record<string, string> = {
    "Content-Type": opts.contentType,
    "Accept-Ranges": "bytes",
    "Cache-Control": "no-store",
  };
  if (opts.downloadName) {
    headers["Content-Disposition"] = `attachment; filename="${opts.downloadName}"`;
  }

  if (range) {
    const match = /bytes=(\d*)-(\d*)/.exec(range);
    const start = match && match[1] ? parseInt(match[1], 10) : 0;
    const end = match && match[2] ? parseInt(match[2], 10) : fileSize - 1;
    const safeStart = Math.max(0, Math.min(start, fileSize - 1));
    const safeEnd = Math.max(safeStart, Math.min(end, fileSize - 1));
    const chunkSize = safeEnd - safeStart + 1;

    const stream = createReadStream(filePath, { start: safeStart, end: safeEnd });
    headers["Content-Range"] = `bytes ${safeStart}-${safeEnd}/${fileSize}`;
    headers["Content-Length"] = String(chunkSize);

    return new Response(nodeStreamToWeb(stream), { status: 206, headers });
  }

  headers["Content-Length"] = String(fileSize);
  const stream = createReadStream(filePath);
  return new Response(nodeStreamToWeb(stream), { status: 200, headers });
}
