import path from "path";
import { promises as fs } from "fs";
import { FFMPEG_BIN, runCommand } from "./ffmpeg";
import { buildAssSubtitle, type CaptionStyleSettings } from "./ass";
import type { CaptionCue } from "./whisper";
import { evenize } from "./frames";

const FONTS_DIR = path.join(process.cwd(), "public", "fonts");

export type RenderTarget = {
  inputPath: string;
  outputPath: string;
  sourceWidth: number;
  sourceHeight: number;
  frameWidth: number; // 0 means "keep original"
  frameHeight: number;
};

export async function renderCaptionedVideo(
  target: RenderTarget,
  cues: CaptionCue[],
  style: CaptionStyleSettings,
  assTmpPath: string,
) {
  const assContent = buildAssSubtitle(cues, style);
  await fs.writeFile(assTmpPath, assContent, "utf-8");

  const useOriginal = target.frameWidth <= 0 || target.frameHeight <= 0;
  const outW = useOriginal ? evenize(target.sourceWidth) : evenize(target.frameWidth);
  const outH = useOriginal ? evenize(target.sourceHeight) : evenize(target.frameHeight);

  const filters: string[] = [];
  if (!useOriginal) {
    filters.push(`scale=w=${outW}:h=${outH}:force_original_aspect_ratio=increase:flags=lanczos`);
    filters.push(`crop=${outW}:${outH}`);
  }
  filters.push(`subtitles=${escapeForFilter(assTmpPath)}:fontsdir=${escapeForFilter(FONTS_DIR)}`);

  const args = [
    "-y",
    "-i",
    target.inputPath,
    "-vf",
    filters.join(","),
    "-c:v",
    "libx264",
    "-preset",
    "veryfast",
    "-crf",
    "20",
    "-pix_fmt",
    "yuv420p",
    "-c:a",
    "aac",
    "-b:a",
    "160k",
    "-movflags",
    "+faststart",
    target.outputPath,
  ];

  await runCommand(FFMPEG_BIN, args);

  await fs.unlink(assTmpPath).catch(() => {});

  return { outputWidth: outW, outputHeight: outH };
}

function escapeForFilter(p: string): string {
  // ffmpeg filtergraph requires escaping ':' and special chars in paths.
  return p.replace(/\\/g, "/").replace(/:/g, "\\:").replace(/'/g, "\\'");
}
