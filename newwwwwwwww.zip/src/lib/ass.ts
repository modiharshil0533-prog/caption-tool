import type { FontOption } from "./fonts";
import type { PaletteOption } from "./palettes";
import type { CaptionCue } from "./whisper";

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

function hexToAssColor(hex: string, opacity = 1): string {
  const clean = hex.replace("#", "");
  const r = clean.slice(0, 2);
  const g = clean.slice(2, 4);
  const b = clean.slice(4, 6);
  const alphaByte = Math.round((1 - clamp(opacity, 0, 1)) * 255);
  const alpha = alphaByte.toString(16).padStart(2, "0").toUpperCase();
  return `&H${alpha}${b.toUpperCase()}${g.toUpperCase()}${r.toUpperCase()}`;
}

function msToAssTime(ms: number): string {
  const total = Math.max(0, Math.round(ms));
  const h = Math.floor(total / 3600000);
  const m = Math.floor((total % 3600000) / 60000);
  const s = Math.floor((total % 60000) / 1000);
  const cs = Math.floor((total % 1000) / 10);
  return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String(cs).padStart(2, "0")}`;
}

function escapeAssText(text: string): string {
  return text.replace(/\\/g, "\\\\").replace(/{/g, "\\{").replace(/}/g, "\\}");
}

function wrapText(text: string, maxCharsPerLine: number, maxLines = 3): string {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let line = "";
  for (const word of words) {
    const candidate = line ? `${line} ${word}` : word;
    if (candidate.length > maxCharsPerLine && line) {
      lines.push(line);
      line = word;
    } else {
      line = candidate;
    }
  }
  if (line) lines.push(line);
  if (lines.length > maxLines) {
    const head = lines.slice(0, maxLines - 1);
    const rest = lines.slice(maxLines - 1).join(" ");
    head.push(rest);
    return head.join("\\N");
  }
  return lines.join("\\N");
}

export type CaptionStyleSettings = {
  font: FontOption;
  palette: PaletteOption;
  fontSizePx: number; // already resolved to target resolution pixels
  positionXPct: number; // 0..100, center x
  positionYPct: number; // 0..100, center y
  uppercase: boolean;
  outputWidth: number;
  outputHeight: number;
  maxWidthPct: number; // 0..100, how wide (of frame) the caption block can get before wrapping
};

export function buildAssSubtitle(cues: CaptionCue[], style: CaptionStyleSettings): string {
  const { font, palette, fontSizePx, positionXPct, positionYPct, uppercase, outputWidth, outputHeight, maxWidthPct } =
    style;

  const primary = hexToAssColor(palette.text, 1);
  const hasBox = Boolean(palette.box);
  const back = hasBox ? hexToAssColor(palette.box as string, palette.boxOpacity) : hexToAssColor("#000000", 0);
  const outlineColor = hexToAssColor(palette.outline, 1);
  const borderStyle = hasBox ? 3 : 1;
  const outlineWidth = hasBox ? Math.max(6, Math.round(fontSizePx * 0.22)) : Math.max(2, Math.round(fontSizePx * 0.08));
  const shadow = hasBox ? 0 : Math.max(1, Math.round(fontSizePx * 0.03));

  const header = `[Script Info]
ScriptType: v4.00+
PlayResX: ${outputWidth}
PlayResY: ${outputHeight}
ScaledBorderAndShadow: yes
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Caption,${font.family},${fontSizePx},${primary},${primary},${outlineColor},${back},${font.bold ? -1 : 0},0,0,0,100,100,0,0,${borderStyle},${outlineWidth},${shadow},5,20,20,20,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

  const posX = Math.round((positionXPct / 100) * outputWidth);
  const posY = Math.round((positionYPct / 100) * outputHeight);
  const maxCharsPerLine = Math.max(
    8,
    Math.round(((maxWidthPct / 100) * outputWidth) / (fontSizePx * 0.56)),
  );

  const lines = cues
    .filter((c) => c.text.trim().length > 0 && c.endMs > c.startMs)
    .map((cue) => {
      const rawText = uppercase ? cue.text.toUpperCase() : cue.text;
      const wrapped = wrapText(escapeAssText(rawText), maxCharsPerLine);
      return `Dialogue: 0,${msToAssTime(cue.startMs)},${msToAssTime(cue.endMs)},Caption,,0,0,0,,{\\an5\\pos(${posX},${posY})}${wrapped}`;
    });

  return header + lines.join("\n") + "\n";
}
