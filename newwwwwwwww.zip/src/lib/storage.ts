import { promises as fs } from "fs";
import path from "path";

export const STORAGE_ROOT = path.join(process.cwd(), "storage");
export const UPLOADS_DIR = path.join(STORAGE_ROOT, "uploads");
export const RENDERS_DIR = path.join(STORAGE_ROOT, "renders");
export const TMP_DIR = path.join(STORAGE_ROOT, "tmp");

export async function ensureStorageDirs() {
  await Promise.all([
    fs.mkdir(UPLOADS_DIR, { recursive: true }),
    fs.mkdir(RENDERS_DIR, { recursive: true }),
    fs.mkdir(TMP_DIR, { recursive: true }),
  ]);
}

export function uploadPath(fileName: string) {
  return path.join(UPLOADS_DIR, fileName);
}

export function renderPath(fileName: string) {
  return path.join(RENDERS_DIR, fileName);
}

export function tmpPath(fileName: string) {
  return path.join(TMP_DIR, fileName);
}
