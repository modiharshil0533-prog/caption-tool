export type PaletteOption = {
  id: string;
  label: string;
  /** main text fill color */
  text: string;
  /** outline / stroke color */
  outline: string;
  /** optional background box color, null = no box */
  box: string | null;
  boxOpacity: number; // 0..1
};

export const PALETTE_OPTIONS: PaletteOption[] = [
  { id: "classic-white", label: "Classic White", text: "#FFFFFF", outline: "#000000", box: null, boxOpacity: 0 },
  { id: "bold-yellow", label: "Bold Yellow", text: "#FFD400", outline: "#000000", box: null, boxOpacity: 0 },
  { id: "hot-pink", label: "Hot Pink", text: "#FF2D87", outline: "#FFFFFF", box: null, boxOpacity: 0 },
  { id: "neon-green", label: "Neon Green", text: "#39FF14", outline: "#042B00", box: null, boxOpacity: 0 },
  { id: "sky-blue", label: "Sky Blue", text: "#00C2FF", outline: "#002233", box: null, boxOpacity: 0 },
  { id: "sunset-orange", label: "Sunset Orange", text: "#FF6B35", outline: "#1A1A1A", box: null, boxOpacity: 0 },
  { id: "royal-purple", label: "Royal Purple", text: "#B388FF", outline: "#1A0033", box: null, boxOpacity: 0 },
  { id: "crimson-red", label: "Crimson Red", text: "#FF3B30", outline: "#FFFFFF", box: null, boxOpacity: 0 },
  { id: "mint", label: "Mint", text: "#00E6C3", outline: "#003B33", box: null, boxOpacity: 0 },
  { id: "gold", label: "Gold", text: "#FFD700", outline: "#5C4300", box: null, boxOpacity: 0 },
  { id: "electric-blue", label: "Electric Blue", text: "#2979FF", outline: "#FFFFFF", box: null, boxOpacity: 0 },
  { id: "coral", label: "Coral", text: "#FF7F6B", outline: "#3A0E08", box: null, boxOpacity: 0 },
  { id: "lime", label: "Lime", text: "#C6FF00", outline: "#2B3300", box: null, boxOpacity: 0 },
  { id: "lavender", label: "Lavender", text: "#D1B3FF", outline: "#2A1A4D", box: null, boxOpacity: 0 },
  { id: "black-on-white", label: "Black on White Box", text: "#000000", outline: "#000000", box: "#FFFFFF", boxOpacity: 0.9 },
  { id: "white-on-black", label: "White on Black Box", text: "#FFFFFF", outline: "#FFFFFF", box: "#000000", boxOpacity: 0.75 },
  { id: "turquoise", label: "Turquoise", text: "#1FE3C4", outline: "#003B33", box: null, boxOpacity: 0 },
  { id: "magenta", label: "Magenta", text: "#E91E8C", outline: "#FFFFFF", box: null, boxOpacity: 0 },
  { id: "fire-red", label: "Fire Red", text: "#FF1744", outline: "#000000", box: null, boxOpacity: 0 },
  { id: "caption-yellow-box", label: "Yellow on Black Box", text: "#FFFF00", outline: "#FFFF00", box: "#000000", boxOpacity: 0.8 },
];

export function getPalette(id: string): PaletteOption {
  return PALETTE_OPTIONS.find((p) => p.id === id) ?? PALETTE_OPTIONS[0];
}
